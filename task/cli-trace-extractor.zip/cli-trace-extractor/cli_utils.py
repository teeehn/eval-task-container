from __future__ import annotations

import json
import os
import platform
import re
import shlex
import socket
import subprocess
from functools import lru_cache
from pathlib import Path

# Extractor version (surfaced via --version and written into every JSON log)
VERSION = "1.20.0"

# Set to True to require --model argument, False to use defaults
MODEL_REQUIRED = True

# Set to True to require --effort-level/--reasoning-effort/--permission-mode, False to use defaults
CONFIG_REQUIRED = True

# Default models (used when MODEL_REQUIRED = False)
CLAUDE_DEFAULT_MODEL = "claude-opus-4-7"
CODEX_DEFAULT_MODEL = "gpt-5.5"
GEMINI_DEFAULT_MODEL = "gemini-3.1-pro-preview"

# Per-model value for CLAUDE_CODE_BASALT_COVE in the Claude launch command. The
# --model value is prefix-matched, so an optional "[1m]" suffix (or a dated
# variant) still matches; the first matching entry wins. A model that matches
# nothing gets no CLAUDE_CODE_BASALT_COVE at all.
CLAUDE_BASALT_COVE_BY_MODEL: dict[str, str] = {
    "claude-avocet": "1",
    "claude-bunting": "1",
    "claude-wigeon": "1",
    "claude-gadwall": "1",
    "claude-grebe": "1",
    "claude-dunlin": "0",
    "claude-warbler": "0",
    "claude-pintail": "0",
    "claude-pochard": "0",
    "claude-smew": "0",
}

# Default config values (used when CONFIG_REQUIRED = False)
CLAUDE_DEFAULT_EFFORT_LEVEL = "xhigh"
CODEX_DEFAULT_REASONING_EFFORT = "xhigh"
CLAUDE_DEFAULT_PERMISSION_MODE = "auto"

# Map our --permission-mode value to the actual Claude Code CLI flag
_CLAUDE_PERMISSION_FLAG = {
    "skip": "--dangerously-skip-permissions",
    "auto": "--permission-mode auto",
}
CLAUDE_PERMISSION_MODES = tuple(_CLAUDE_PERMISSION_FLAG)

# Settings always passed via Claude's --settings flag. By default forces thinking
# mode on regardless of the worker's local /config toggle (which would otherwise
# persist `alwaysThinkingEnabled: false` in ~/.claude/settings.json). When
# --disable-thinking is set, _build_claude_settings_json sets this to False AND
# adds `env: {MAX_THINKING_TOKENS: "0"}` (the authoritative API-level force-off,
# since the bool alone is only a session default), and the launch command drops
# --thinking-display. Flag-gated additions (e.g. showThinkingSummaries via
# --show-thinking-summaries) are merged in at launch-command-build time by
# _build_claude_settings_json.
CLAUDE_BASE_SETTINGS: dict[str, object] = {"alwaysThinkingEnabled": True}

# CLI command templates with placeholders. `settings_json` for Claude is built
# dynamically in build_launch_command from CLAUDE_BASE_SETTINGS plus any
# flag-gated additions. `thinking_display` is "--thinking-display summarized "
# normally and "" when --disable-thinking is set (nothing to display).
CLAUDE_CMD_TEMPLATE = "API_FORCE_IDLE_TIMEOUT=0 API_TIMEOUT_MS=1800000 CLAUDE_CODE_MAX_OUTPUT_TOKENS=64000 ANTHROPIC_MODEL={model} claude {permission_flag} --effort {effort_level} {thinking_display}--settings {settings_json}"
CODEX_CMD_TEMPLATE = (
    'codex --sandbox workspace-write --ask-for-approval on-request --disable fast_mode '
    '--config sandbox_workspace_write.network_access=true '
    '--model {model} --config model_reasoning_effort="{reasoning_effort}" '
    '--config model_reasoning_summary="auto"'
)
GEMINI_CMD_TEMPLATE = "gemini --model {model}"

# Proxy base URL seeded into the redirected (empty) CODEX_HOME so Codex routes
# through the LLM proxy instead of api.openai.com.
CODEX_OPENAI_BASE_URL = "https://app-llmproxy.dataannotation.tech/api/llm_proxy/openai/v1"


@lru_cache(maxsize=1)
def get_platform_info() -> tuple[str, bool]:
    system = platform.system()
    is_wsl = False
    if system == "Linux":
        try:
            with open("/proc/version", "r") as f:
                is_wsl = "microsoft" in f.read().lower()
        except Exception:
            pass
    return system, is_wsl


@lru_cache(maxsize=1)
def get_cert_path() -> Path:
    return Path.home() / ".mitmproxy" / "mitmproxy-ca-cert.pem"


def get_shell_name() -> str:
    shell = os.environ.get("SHELL", "")
    if shell:
        return Path(shell).name
    system, _ = get_platform_info()
    return "cmd" if system == "Windows" else "bash"


def seed_codex_config(codex_home: Path) -> None:
    """Write a minimal config.toml (just openai_base_url) into a redirected
    CODEX_HOME so Codex routes through the LLM proxy."""
    (codex_home / "config.toml").write_text(
        f'openai_base_url = "{CODEX_OPENAI_BASE_URL}"\n'
    )


def _claude_basalt_cove_value(model: str) -> str | None:
    for prefix, value in CLAUDE_BASALT_COVE_BY_MODEL.items():
        if model.startswith(prefix):
            return value
    return None


def _build_claude_settings_json(show_thinking_summaries: bool, disable_thinking: bool = False) -> str:
    """Serialize Claude's --settings JSON, shell-quoted for direct insertion into the launch command."""
    settings = dict(CLAUDE_BASE_SETTINGS)
    if disable_thinking:
        # alwaysThinkingEnabled only sets the session DEFAULT — the in-session
        # Option+T toggle can still flip thinking back on. The authoritative
        # force-off is MAX_THINKING_TOKENS=0, which disables thinking on the
        # Anthropic API regardless of effort (per Claude Code docs; no effect on
        # Fable 5). Set both: the env var forces it off, the bool keeps the
        # session default and the display off too.
        settings["alwaysThinkingEnabled"] = False
        settings["env"] = {"MAX_THINKING_TOKENS": "0"}
    if show_thinking_summaries:
        settings["showThinkingSummaries"] = True
    return shlex.quote(json.dumps(settings, separators=(",", ":")))


def build_launch_command(
    cert_path: Path,
    port: int,
    cli: str,
    model: str,
    effort_level: str | None = None,
    reasoning_effort: str | None = None,
    permission_mode: str | None = None,
    tmux_session: str | None = None,
    verbose: bool = False,
    disable_autoupdate: bool = False,
    show_thinking_summaries: bool = False,
    disable_thinking: bool = False,
    claude_config_dir: Path | None = None,
    codex_home: Path | None = None,
) -> str:
    system, _ = get_platform_info()
    proxy_url = f"http://127.0.0.1:{port}"
    env_vars = f'NODE_EXTRA_CA_CERTS="{cert_path}" HTTPS_PROXY="{proxy_url}"'

    if cli == "claude":
        effort = effort_level if effort_level is not None else CLAUDE_DEFAULT_EFFORT_LEVEL
        pmode = permission_mode if permission_mode is not None else CLAUDE_DEFAULT_PERMISSION_MODE
        permission_flag = _CLAUDE_PERMISSION_FLAG[pmode]
        settings_json = _build_claude_settings_json(show_thinking_summaries, disable_thinking)
        cmd = CLAUDE_CMD_TEMPLATE.format(
            model=model,
            effort_level=effort,
            permission_flag=permission_flag,
            settings_json=settings_json,
            thinking_display="" if disable_thinking else "--thinking-display summarized ",
        )
        if verbose:
            cmd += " --verbose"
        # CLAUDE_CONFIG_DIR redirects Claude Code's per-session state (session
        # JSONL, debug log, etc.) into the supplied dir for this invocation
        # only. --debug is paired so the debug log is actually written under it.
        if claude_config_dir is not None:
            cmd += " --debug"
            env_vars = f"CLAUDE_CONFIG_DIR={shlex.quote(str(claude_config_dir))} {env_vars}"
        if disable_autoupdate:
            env_vars = f"DISABLE_AUTOUPDATER=1 {env_vars}"
        basalt_cove = _claude_basalt_cove_value(model)
        if basalt_cove is not None:
            env_vars = f"{env_vars} CLAUDE_CODE_BASALT_COVE={basalt_cove}"
    elif cli == "codex":
        effort = reasoning_effort if reasoning_effort is not None else CODEX_DEFAULT_REASONING_EFFORT
        cmd = CODEX_CMD_TEMPLATE.format(model=model, reasoning_effort=effort)
        # CODEX_HOME redirects Codex's per-run state (including the native session
        # rollout transcripts under sessions/) into the supplied dir for this
        # invocation only.
        if codex_home is not None:
            env_vars = f"CODEX_HOME={shlex.quote(str(codex_home))} {env_vars}"
    elif cli == "gemini":
        cmd = GEMINI_CMD_TEMPLATE.format(model=model)
    else:
        raise ValueError(f"Unknown CLI: {cli}")

    # Windows lacks native tmux; the wrap is not applied here.
    if system == "Windows":
        autoupdate_prefix = '$env:DISABLE_AUTOUPDATER="1"; ' if (cli == "claude" and disable_autoupdate) else ""
        config_prefix = ""
        if cli == "claude" and claude_config_dir is not None:
            config_prefix = f'$env:CLAUDE_CONFIG_DIR="{claude_config_dir}"; '
        elif cli == "codex" and codex_home is not None:
            config_prefix = f'$env:CODEX_HOME="{codex_home}"; '
        gated_suffix = ""
        if cli == "claude":
            basalt_cove = _claude_basalt_cove_value(model)
            if basalt_cove is not None:
                gated_suffix = f'$env:CLAUDE_CODE_BASALT_COVE="{basalt_cove}"; '
        return f'{autoupdate_prefix}{config_prefix}$env:NODE_EXTRA_CA_CERTS="{cert_path}"; $env:HTTPS_PROXY="{proxy_url}"; {gated_suffix}{cmd}'

    if get_shell_name() == "fish":
        base = f"env {env_vars} {cmd}"
    else:
        base = f"{env_vars} {cmd}"

    # shlex.quote is required because cmd may contain shell metacharacters (e.g. nested quotes).
    if tmux_session:
        return f"tmux new-session -s {tmux_session} {shlex.quote(base)}"
    return base


# Regex for extracting M.N.P from `<cli> --version` stdout. Observed outputs:
#   claude --version  -> "2.1.138 (Claude Code)"
#   codex --version   -> "codex-cli 0.125.0"
#   gemini --version  -> "0.39.1"
# Pre-release suffixes (e.g. "0.131.0-alpha.4") are not captured beyond M.N.P.
_CLI_VERSION_RE = re.compile(r"\d+\.\d+\.\d+")

# Subprocess timeout for `<cli> --version`. Bounds banner-display delay if the
# binary hangs.
_CLI_VERSION_TIMEOUT_S = 5


def get_cli_version(cli: str) -> str | None:
    """Return the installed semver of <cli>, or None if not detectable.

    Runs `<cli> --version` and extracts the first M.N.P semver from stdout.
    Returns None on: not-on-PATH, non-zero exit, timeout, no match, or any
    subprocess error. Never raises (called from proxy logger addon __init__).
    """
    try:
        result = subprocess.run(
            [cli, "--version"],
            capture_output=True,
            text=True,
            timeout=_CLI_VERSION_TIMEOUT_S,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    match = _CLI_VERSION_RE.search(result.stdout)
    return match.group(0) if match else None


def format_cli_install_hint(cli: str, version: str) -> str:
    """Return the shell command for installing <cli> at <version>.

    Claude uses Anthropic's native installer (platform-specific); codex and
    gemini use npm `@<version>` syntax. Returns "" for an unknown CLI.
    """
    if cli == "claude":
        # https://code.claude.com/docs/en/setup#install-a-specific-version
        system, _ = get_platform_info()
        if system == "Windows":
            template = "& ([scriptblock]::Create((irm https://claude.ai/install.ps1))) {version}"
        else:
            template = "curl -fsSL https://claude.ai/install.sh | bash -s {version}"
    elif cli == "codex":
        # https://www.npmjs.com/package/@openai/codex
        template = "npm install -g @openai/codex@{version}"
    elif cli == "gemini":
        # https://www.npmjs.com/package/@google/gemini-cli
        template = "npm install -g @google/gemini-cli@{version}"
    else:
        return ""
    return template.format(version=version)


def enforce_cli_version(cli: str, required: str) -> str | None:
    """Check that <cli> on PATH is exactly <required>. Returns None on match, else a multi-line error message ready to print."""
    installed = get_cli_version(cli)
    hint = format_cli_install_hint(cli, required)
    install_line = f"\n  To install the required version, run:\n    {hint}" if hint else ""
    if installed is None:
        return (
            f"ERROR: {cli} is not on PATH or its version could not be detected.\n"
            f"  --require-cli-version is set to {required}.{install_line}"
        )
    if installed != required:
        return (
            f"ERROR: {cli} version mismatch.\n"
            f"  Installed: {installed}\n"
            f"  Required:  {required} (via --require-cli-version){install_line}"
        )
    return None


def is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard. Returns True if successful."""
    system, _ = get_platform_info()
    try:
        if system == "Darwin":
            subprocess.run(["pbcopy"], input=text.encode(), check=True)
            return True
        if system == "Linux":
            try:
                subprocess.run(["xclip", "-selection", "clipboard"], input=text.encode(), check=True)
                return True
            except FileNotFoundError:
                try:
                    subprocess.run(["xsel", "--clipboard", "--input"], input=text.encode(), check=True)
                    return True
                except FileNotFoundError:
                    return False
        if system == "Windows":
            subprocess.run(["clip"], input=text.encode(), check=True, shell=True)
            return True
    except Exception:
        pass
    return False
