"""Claude Code Trace Extractor - captures conversations with latency metrics."""

from __future__ import annotations

import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Optional

import orjson

from cli_utils import (
    build_launch_command,
    copy_to_clipboard,
    enforce_cli_version,
    get_cert_path,
    get_cli_version,
    get_platform_info,
    is_port_free,
    VERSION,
    MODEL_REQUIRED,
    CONFIG_REQUIRED,
    CLAUDE_DEFAULT_MODEL,
    CLAUDE_DEFAULT_EFFORT_LEVEL,
    CLAUDE_DEFAULT_PERMISSION_MODE,
    CLAUDE_PERMISSION_MODES,
)

def json_loads(s): return orjson.loads(s)
def json_dumps(obj): return orjson.dumps(obj, option=orjson.OPT_INDENT_2)

SAVE_EVERY_TURNS = 5
SAVE_EVERY_SECS = 5.0

# Supported API hosts for Claude/Anthropic
CLAUDE_API_HOSTS = ("anthropic.com", "dataannotation.tech")

if TYPE_CHECKING:
    from mitmproxy import http

# mitmproxy's own content decoder (gzip/deflate/br/zstd), used to decode streamed
# SSE bodies. They arrive still-encoded via flow.response.stream, unlike buffered
# flow.response.content (which mitmproxy decodes automatically). Guarded so the
# module imports even without mitmproxy, matching the addon import below.
try:
    from mitmproxy.net import encoding as _mitm_encoding
except Exception:
    _mitm_encoding = None


def _iter_sse_data(text: str):
    data_parts = []
    for line in text.splitlines():
        if line == "":
            if data_parts:
                yield "\n".join(data_parts)
                data_parts = []
            continue
        if line.startswith("data:"):
            data_parts.append(line[5:].lstrip())
    if data_parts:
        yield "\n".join(data_parts)


def _decode_sse_body(raw: bytes, content_encoding: str) -> bytes:
    """Decode a streamed (possibly truncated) SSE body by its Content-Encoding,
    using mitmproxy's own decoder. Returns the raw bytes for identity/unknown
    encodings or on any decode failure, so the turn is still recorded (the SSE
    parser simply finds no events in undecodable bytes)."""
    if not raw:
        return b""
    enc = (content_encoding or "").lower().strip()
    if enc in ("", "identity") or _mitm_encoding is None:
        return bytes(raw)
    try:
        out = _mitm_encoding.decode(bytes(raw), enc)
        return out if isinstance(out, (bytes, bytearray)) else bytes(raw)
    except Exception:
        return bytes(raw)


class TurnMetrics:
    def __init__(self):
        self.turn_id = 0
        self.timestamp = ""
        self.model = ""
        self.request_id = ""
        self.message_id = ""

        self.messages_count = 0
        self.user_message = ""
        self.system_prompt = ""
        # role:system messages inside the messages array (mid-conversation system).
        self.mid_conversation_system = []
        self.request_size_bytes = 0
        self.max_tokens = 0
        self.thinking_budget_tokens = 0
        self.tools_count = 0

        self.request_start = 0.0
        self.first_byte = None
        self.stream_end = None
        self.server_time_ms = 0

        self.input_tokens = 0
        self.output_tokens = 0
        self.cache_creation_input_tokens = 0
        self.cache_read_input_tokens = 0
        self.cache_creation_5m_tokens = 0
        self.cache_creation_1h_tokens = 0

        self.ratelimit_input_tokens_limit = 0
        self.ratelimit_input_tokens_remaining = 0
        self.ratelimit_requests_limit = 0
        self.ratelimit_requests_remaining = 0

        self.thinking_parts = []
        self.text_parts = []
        self.tool_uses = []
        self.stop_reason = ""
        self.response_size_bytes = 0
        self.service_tier = ""
        self.context_mgmt_edits = []

        self.total_events = 0
        self.first_thinking_idx = None
        self.first_text_idx = None

        # Streaming-passthrough state. stream_buf accumulates the still-encoded
        # response body forwarded via flow.response.stream. aborted marks a turn
        # that ended mid-flight (recorded so failures stay visible).
        self.stream_buf = None
        self.content_encoding = ""
        self.was_streamed = False
        self.aborted = False
        self.error_message = ""

    def to_dict(self) -> dict:
        fb, rs, se = self.first_byte, self.request_start, self.stream_end

        ttfb = round((fb - rs) * 1000, 1) if fb and rs else None
        ttlt = round((se - rs) * 1000, 1) if se and rs else None
        stream_dur = (se - fb) if se and fb else 0

        ttf_thinking = ttf_answer = None
        if self.total_events > 0 and ttfb:
            if self.first_thinking_idx is not None:
                ttf_thinking = round(ttfb + (stream_dur * self.first_thinking_idx / self.total_events * 1000), 1)
            if self.first_text_idx is not None:
                ttf_answer = round(ttfb + (stream_dur * self.first_text_idx / self.total_events * 1000), 1)

        otps = round(self.output_tokens / (ttlt / 1000), 1) if ttlt and ttlt > 0 and self.output_tokens > 0 else None
        total_input = self.input_tokens

        thinking_text = "".join(self.thinking_parts)
        response_text = "".join(self.text_parts)

        # Estimate thinking/text/tool token breakdown (proportional by character count)
        thinking_chars = len(thinking_text)
        text_chars = len(response_text)
        tool_chars = 0
        for tool in self.tool_uses:
            tool_chars += len(tool.get("name", ""))
            tool_input = tool.get("input", "")
            if isinstance(tool_input, str):
                tool_chars += len(tool_input)
            else:
                tool_chars += len(orjson.dumps(tool_input))
        total_content_chars = thinking_chars + text_chars + tool_chars

        if total_content_chars > 0 and self.output_tokens > 0:
            est_thinking = int(self.output_tokens * thinking_chars / total_content_chars)
            est_text = int(self.output_tokens * text_chars / total_content_chars)
            est_tool = self.output_tokens - est_thinking - est_text
            estimated_output = {
                "thinking": est_thinking,
                "non_thinking": {
                    "total": self.output_tokens - est_thinking,
                    "text": est_text,
                    "tool": est_tool,
                },
            }
        else:
            estimated_output = {
                "thinking": None,
                "non_thinking": {"total": None, "text": None, "tool": None},
            }

        return {
            "turn": self.turn_id,
            "timestamp": self.timestamp,
            "request_id": self.request_id,
            "message_id": self.message_id,
            "model": self.model,
            "service_tier": self.service_tier,
            "request": {
                "messages_count": self.messages_count,
                "user_message": self.user_message,
                "system_prompt": self.system_prompt,
                "mid_conversation_system": self.mid_conversation_system,
                "size_bytes": self.request_size_bytes,
                "max_tokens": self.max_tokens,
                "thinking_budget_tokens": self.thinking_budget_tokens,
                "tools_count": self.tools_count,
            },
            "response": {
                "thinking": thinking_text,
                "text": response_text,
                "tool_uses": self.tool_uses,
                "stop_reason": self.stop_reason,
                "size_bytes": self.response_size_bytes,
                "context_mgmt_edits": self.context_mgmt_edits,
            },
            "tokens": {
                "input": self.input_tokens,
                "output": self.output_tokens,
                "estimated_output": estimated_output,
                "cache_creation": self.cache_creation_input_tokens,
                "cache_read": self.cache_read_input_tokens,
                "cache_creation_5m": self.cache_creation_5m_tokens,
                "cache_creation_1h": self.cache_creation_1h_tokens,
                "total_input": total_input,
            },
            "latency": {
                "server_time_ms": self.server_time_ms,
                "ttfb_ms": ttfb,
                "ttf_thinking_ms": ttf_thinking,
                "ttf_answer_ms": ttf_answer,
                "ttlt_ms": ttlt,
            },
            "tool_call_count": len(self.tool_uses),
            "aborted": self.aborted,
            "error": self.error_message or None,
            "throughput": {"output_tokens_per_sec": otps},
            "rate_limits": {
                "input_tokens_limit": self.ratelimit_input_tokens_limit,
                "input_tokens_remaining": self.ratelimit_input_tokens_remaining,
                "requests_limit": self.ratelimit_requests_limit,
                "requests_remaining": self.ratelimit_requests_remaining,
            },
            "events_count": self.total_events,
        }



class ConversationLog:
    __slots__ = ('log_dir', 'run_id', 'session_id', 'session_start', 'log_file', 'turns', 'turn_counter',
                 'total_input_tokens', 'total_output_tokens', 'total_cache_read',
                 'total_cache_creation', 'total_latency_ms', 'models_used',
                 '_sum_server', '_sum_ttfb', '_sum_ttlt', '_sum_otps',
                 '_sum_ttf_thinking', '_sum_ttf_answer',
                 '_cnt_server', '_cnt_ttfb', '_cnt_ttlt', '_cnt_otps',
                 '_cnt_ttf_thinking', '_cnt_ttf_answer',
                 '_last_save_ts', '_last_save_turn', 'total_tool_calls',
                 'total_estimated_thinking_tokens', 'total_estimated_text_tokens',
                 'total_estimated_tool_tokens', 'claude_code_metrics',
                 'cli_version', 'claude_config_dir', 'thinking_disabled', 'aborted_turns')

    def __init__(self, log_dir: Path, run_id: str = "", claude_config_dir: str = "", thinking_disabled: bool = False):
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.run_id = run_id
        self.session_id: Optional[str] = None
        self.session_start: Optional[str] = None
        self.log_file: Optional[Path] = None
        self.turns: list[dict] = []
        self.turn_counter = 0

        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_cache_read = 0
        self.total_cache_creation = 0
        self.total_latency_ms = 0.0
        self.models_used: set = set()

        self._sum_server = self._sum_ttfb = self._sum_ttlt = self._sum_otps = 0.0
        self._sum_ttf_thinking = self._sum_ttf_answer = 0.0
        self._cnt_server = self._cnt_ttfb = self._cnt_ttlt = self._cnt_otps = 0
        self._cnt_ttf_thinking = self._cnt_ttf_answer = 0
        self._last_save_ts = 0.0
        self._last_save_turn = 0
        self.total_tool_calls = 0
        self.aborted_turns = 0
        self.total_estimated_thinking_tokens = 0
        self.total_estimated_text_tokens = 0
        self.total_estimated_tool_tokens = 0
        self.claude_code_metrics: Optional[dict] = None
        # None when claude is not on PATH or `claude --version` is unparseable.
        self.cli_version: Optional[str] = get_cli_version("claude")
        # CLAUDE_CONFIG_DIR set on the launch command for this run. None when
        # --no-claude-config was set or the option was not passed.
        self.claude_config_dir: Optional[str] = claude_config_dir or None
        # Whether the extractor launched Claude Code with --disable-thinking
        # (alwaysThinkingEnabled:false + MAX_THINKING_TOKENS=0). This records the
        # LAUNCH CONFIGURATION the extractor applied, not a wire-level confirmation
        # that the API disabled thinking. Sourced from the --disable-thinking flag.
        self.thinking_disabled: bool = thinking_disabled

    def _init_session(self, request_id: str):
        if self.session_id:
            return
        self.session_id = request_id[4:12] if request_id.startswith("req_") else (request_id[:8] or "unknown")
        self.session_start = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.log_dir / "trace.json"

    def add_turn(self, metrics: TurnMetrics) -> tuple[bool, str]:
        """Add a turn and maybe save. Returns (saved, filename) if intermediate save occurred."""
        self._init_session(metrics.request_id)
        self.turn_counter += 1
        metrics.turn_id = self.turn_counter

        turn_data = metrics.to_dict()
        self.turns.append(turn_data)
        self.models_used.add(turn_data["model"])

        # Aborted turns are recorded for visibility but excluded from token/
        # latency/throughput aggregates (their partial counts would skew averages).
        if turn_data.get("aborted"):
            self.aborted_turns += 1
            return self._maybe_save()

        tokens = turn_data["tokens"]
        latency = turn_data["latency"]
        throughput = turn_data["throughput"]

        self.total_input_tokens += tokens["input"]
        self.total_output_tokens += tokens["output"]
        self.total_cache_read += tokens["cache_read"]
        self.total_cache_creation += tokens["cache_creation"]
        self.total_tool_calls += turn_data["tool_call_count"]
        est = tokens.get("estimated_output", {})
        if est.get("thinking") is not None:
            self.total_estimated_thinking_tokens += est["thinking"]
            self.total_estimated_text_tokens += est["non_thinking"]["text"]
            self.total_estimated_tool_tokens += est["non_thinking"]["tool"]

        if latency["server_time_ms"]:
            self._sum_server += latency["server_time_ms"]
            self._cnt_server += 1
        if latency["ttfb_ms"]:
            self._sum_ttfb += latency["ttfb_ms"]
            self._cnt_ttfb += 1
        if latency["ttf_thinking_ms"]:
            self._sum_ttf_thinking += latency["ttf_thinking_ms"]
            self._cnt_ttf_thinking += 1
        if latency["ttf_answer_ms"]:
            self._sum_ttf_answer += latency["ttf_answer_ms"]
            self._cnt_ttf_answer += 1
        if latency["ttlt_ms"]:
            self._sum_ttlt += latency["ttlt_ms"]
            self._cnt_ttlt += 1
            self.total_latency_ms += latency["ttlt_ms"]
        if throughput["output_tokens_per_sec"]:
            self._sum_otps += throughput["output_tokens_per_sec"]
            self._cnt_otps += 1

        return self._maybe_save()

    def _parse_session_cost(self) -> dict:
        """Extract cost from claude_code_metrics. Returns empty dict if unavailable."""
        if not self.claude_code_metrics:
            return {"total_cost_usd": None, "cost_by_model": {}}

        for m in self.claude_code_metrics.get("metrics", []):
            if m.get("name") == "claude_code.cost.usage":
                data_points = m.get("data_points", [])
                if not data_points:
                    break
                total_cost = 0.0
                cost_by_model = {}
                for dp in data_points:
                    val = dp.get("value", 0)
                    total_cost += val
                    model = dp.get("attributes", {}).get("model", "unknown")
                    cost_by_model[model] = round(cost_by_model.get(model, 0) + val, 6)
                return {"total_cost_usd": round(total_cost, 6), "cost_by_model": cost_by_model}

        return {"total_cost_usd": None, "cost_by_model": {}}

    def _compute_summary(self) -> dict:
        last_rl = self.turns[-1]["rate_limits"] if self.turns else {}

        return {
            "total_turns": len(self.turns),
            "aborted_turns": self.aborted_turns,
            "total_tool_calls": self.total_tool_calls,
            "models_used": sorted(self.models_used),
            "tokens": {
                "total_input": self.total_input_tokens,
                "total_output": self.total_output_tokens,
                "estimated_output": {
                    "thinking": self.total_estimated_thinking_tokens,
                    "non_thinking": {
                        "total": self.total_estimated_text_tokens + self.total_estimated_tool_tokens,
                        "text": self.total_estimated_text_tokens,
                        "tool": self.total_estimated_tool_tokens,
                    },
                },
                "total_cache_read": self.total_cache_read,
                "total_cache_creation": self.total_cache_creation,
            },
            "cost": self._parse_session_cost(),
            "latency": {
                "avg_server_time_ms": round(self._sum_server / self._cnt_server, 1) if self._cnt_server else 0.0,
                "avg_ttfb_ms": round(self._sum_ttfb / self._cnt_ttfb, 1) if self._cnt_ttfb else 0.0,
                "avg_ttf_thinking_ms": round(self._sum_ttf_thinking / self._cnt_ttf_thinking, 1) if self._cnt_ttf_thinking else 0.0,
                "avg_ttf_answer_ms": round(self._sum_ttf_answer / self._cnt_ttf_answer, 1) if self._cnt_ttf_answer else 0.0,
                "avg_ttlt_ms": round(self._sum_ttlt / self._cnt_ttlt, 1) if self._cnt_ttlt else 0.0,
                "total_ms": round(self.total_latency_ms, 1),
            },
            "throughput": {
                "avg_output_tokens_per_sec": round(self._sum_otps / self._cnt_otps, 1) if self._cnt_otps else 0.0,
            },
            "rate_limits": last_rl,
        }

    def _save(self) -> bool:
        if not self.log_file:
            return False
        try:
            data = {
                "session": {
                    "id": self.session_id,
                    "started_at": self.session_start,
                    "exported_at": datetime.now().isoformat(),
                    "extractor_version": VERSION,
                    "cli_version": self.cli_version,
                    "claude_config_dir": self.claude_config_dir,
                    "thinking_disabled": self.thinking_disabled,
                },
                "summary": self._compute_summary(),
                "turns": self.turns,
            }
            if self.claude_code_metrics:
                data["claude_code_metrics"] = self.claude_code_metrics
            self.log_file.write_bytes(json_dumps(data))
        except Exception as e:
            print(f"[LOG] Save failed: {e}", file=sys.stderr)
            return False
        return True

    def _maybe_save(self) -> tuple[bool, str]:
        """Returns (saved, filename) if a save occurred."""
        now = time.monotonic()
        if (
            self.turn_counter - self._last_save_turn >= SAVE_EVERY_TURNS
            or now - self._last_save_ts >= SAVE_EVERY_SECS
        ):
            if self._save():
                self._last_save_ts = now
                self._last_save_turn = self.turn_counter
                return True, self.log_file.name
        return False, ""

    def save(self) -> tuple[bool, str]:
        """Final save. Returns (saved, filename)."""
        if self._save():
            return True, self.log_file.name if self.log_file else ""
        return False, ""

    def get_final_summary(self) -> str:
        if not self.turns:
            return "No conversation data captured."

        summary = self._compute_summary()
        tok = summary["tokens"]
        lat = summary["latency"]

        lines = [
            f"Session: {self.session_id}",
            f"  Turns: {summary['total_turns']}",
            f"  Models: {', '.join(summary['models_used'])}",
            f"  Tokens: {tok['total_input']:,} in / {tok['total_output']:,} out",
            f"  Avg TTFB: {lat['avg_ttfb_ms']:.0f}ms",
            f"  Total time: {lat['total_ms']/1000:.1f}s",
        ]

        if self.claude_code_metrics:
            metrics = self.claude_code_metrics.get("metrics", [])
            for m in metrics:
                if m.get("name") == "claude_code.cost.usage":
                    total_cost = sum(dp.get("value", 0) for dp in m.get("data_points", []))
                    lines.append(f"  Cost: ${total_cost:.4f}")
                    break

        return "\n".join(lines)


try:
    from mitmproxy import http, ctx

    class ClaudeLatencyAddon:
        __slots__ = ('active_requests', 'conversation_log', '_session_started', '_shutdown_flag')

        def __init__(self):
            self.active_requests: dict[str, TurnMetrics] = {}
            self.conversation_log: Optional[ConversationLog] = None
            self._session_started: bool = False
            self._shutdown_flag: bool = False

        def load(self, loader):
            loader.add_option(name="latency_log_dir", typespec=str, default="",
                              help="Directory for logging conversations")
            loader.add_option(name="run_id", typespec=str, default="",
                              help="Run identifier embedded in the JSON trace filename for cross-file matching")
            loader.add_option(name="claude_config_dir", typespec=str, default="",
                              help="Per-run path under claude_config/ where Claude Code's raw state ends up after the shutdown rename (claude_config/<run_id>/). Recorded as session.claude_config_dir in the JSON trace. Note: differs from the CLAUDE_CONFIG_DIR literal in the launch command, which uses the stable runtime path claude_config/active_<port>/.")
            loader.add_option(name="thinking_disabled", typespec=bool, default=False,
                              help="Whether the launch command was built with --disable-thinking (alwaysThinkingEnabled:false + MAX_THINKING_TOKENS=0). Recorded as session.thinking_disabled in the JSON trace. Reflects the launch configuration applied, not a wire-level confirmation that the API disabled thinking.")

        def configure(self, updates):
            # Only initialize once: a later runtime option change must not discard
            # the in-flight session's accumulated turns.
            if self.conversation_log is not None:
                return
            if "latency_log_dir" in updates or "run_id" in updates or "claude_config_dir" in updates:
                log_dir = ctx.options.latency_log_dir
                if log_dir:
                    self.conversation_log = ConversationLog(
                        Path(log_dir),
                        run_id=ctx.options.run_id,
                        claude_config_dir=ctx.options.claude_config_dir,
                        thinking_disabled=ctx.options.thinking_disabled,
                    )

        def done(self):
            """Called when proxy shuts down (Ctrl+C)."""
            if self._shutdown_flag:
                return
            self._shutdown_flag = True

            # Tracked turns still in flight at shutdown were never recorded (e.g. a
            # mid-turn Ctrl+C). Surface the count rather than dropping them silently.
            if self.active_requests:
                ctx.log.warn(f"[LOG] {len(self.active_requests)} request(s) still in flight at shutdown (not recorded)")

            if self.conversation_log:
                saved, filename = self.conversation_log.save()
                if saved:
                    ctx.log.info(f"[LOG] Final save completed → {filename}")

            print()
            if self.conversation_log and self.conversation_log.log_file and self.conversation_log.turns:
                print(f"Trace saved to: {self.conversation_log.log_file}")
            else:
                print("No conversation data captured.")

        def _sanitize_metrics(self, metrics: dict) -> dict:
            sensitive_keys = {"user.id", "user.email", "user.account_uuid", "organization.id"}

            def sanitize_attrs(attrs: dict) -> dict:
                return {k: v for k, v in attrs.items() if k not in sensitive_keys}

            sanitized = {}
            if "resource_attributes" in metrics:
                sanitized["resource_attributes"] = sanitize_attrs(metrics["resource_attributes"])

            if "metrics" in metrics:
                sanitized["metrics"] = []
                for m in metrics["metrics"]:
                    sanitized_metric = {
                        "name": m.get("name"),
                        "description": m.get("description"),
                        "unit": m.get("unit"),
                        "data_points": []
                    }
                    for dp in m.get("data_points", []):
                        sanitized_dp = {"value": dp.get("value"), "timestamp": dp.get("timestamp")}
                        if "attributes" in dp:
                            sanitized_dp["attributes"] = sanitize_attrs(dp["attributes"])
                        sanitized_metric["data_points"].append(sanitized_dp)
                    sanitized["metrics"].append(sanitized_metric)

            return sanitized

        def request(self, flow: http.HTTPFlow):
            req = flow.request
            if not any(host in req.host for host in CLAUDE_API_HOSTS):
                return

            # Capture metrics when session sends them (but don't auto-shutdown)
            if req.path.endswith("/claude_code/metrics"):
                if req.content and self.conversation_log:
                    try:
                        self.conversation_log.claude_code_metrics = self._sanitize_metrics(json_loads(req.content))
                        ctx.log.info("Captured session metrics")
                    except Exception:
                        pass
                return

            if req.method != "POST" or "/v1/messages" not in req.path:
                return
            if "batch" in req.path or "count" in req.path:
                return

            try:
                body = json_loads(req.content)
                if not body.get("stream"):
                    return

                messages = body.get("messages")
                # Match on any user message, not just a trailing one (Claude can
                # append a system message after the user turn, mid-conversation).
                if not messages or not any(m.get("role") == "user" for m in messages):
                    return

                if not self._session_started:
                    self._session_started = True
                    ctx.log.info("Claude Code session detected!")

                thinking = body.get("thinking", {})
                tools = body.get("tools", [])

                metrics = TurnMetrics()
                metrics.timestamp = datetime.now().isoformat()
                metrics.model = body.get("model", "unknown")
                metrics.request_start = time.perf_counter()
                metrics.messages_count = len(messages)
                metrics.request_size_bytes = len(req.content) if req.content else 0
                metrics.max_tokens = body.get("max_tokens", 0)
                metrics.thinking_budget_tokens = thinking.get("budget_tokens", 0) if isinstance(thinking, dict) else 0
                metrics.tools_count = len(tools)

                user_msg = next((m for m in reversed(messages) if m.get("role") == "user"), None)
                user_content = user_msg.get("content", "") if user_msg else ""
                if isinstance(user_content, list):
                    user_content = " ".join(b.get("text", "") for b in user_content if b.get("type") == "text")
                metrics.user_message = str(user_content)

                mid_system = []
                for m in messages:
                    if m.get("role") == "system":
                        sys_content = m.get("content", "")
                        if isinstance(sys_content, list):
                            sys_content = " ".join(b.get("text", "") for b in sys_content if b.get("type") == "text")
                        mid_system.append(str(sys_content))
                metrics.mid_conversation_system = mid_system

                system = body.get("system", "")
                if isinstance(system, list):
                    system = " ".join(b.get("text", "") for b in system if b.get("type") == "text")
                metrics.system_prompt = str(system)

                self.active_requests[flow.id] = metrics
                ctx.log.info(f"[TURN] Started: {metrics.model}")

            except Exception as e:
                ctx.log.warn(f"[TURN] Parse error: {e}")

        def responseheaders(self, flow: http.HTTPFlow):
            metrics = self.active_requests.get(flow.id)
            if not metrics:
                return

            metrics.first_byte = time.perf_counter()
            h = flow.response.headers

            # Direct API uses request-id; proxies may use x-request-id
            metrics.request_id = h.get("request-id", h.get("x-request-id", ""))
            metrics.server_time_ms = int(h.get("x-envoy-upstream-service-time", 0) or 0)
            metrics.ratelimit_input_tokens_limit = int(h.get("anthropic-ratelimit-input-tokens-limit", 0) or 0)
            metrics.ratelimit_input_tokens_remaining = int(h.get("anthropic-ratelimit-input-tokens-remaining", 0) or 0)
            metrics.ratelimit_requests_limit = int(h.get("anthropic-ratelimit-requests-limit", 0) or 0)
            metrics.ratelimit_requests_remaining = int(h.get("anthropic-ratelimit-requests-remaining", 0) or 0)

            # Forward SSE chunks to the client as they arrive instead of mitmproxy's
            # default buffer-until-complete, so the client is not blocked until the
            # upstream response finishes. The tap copies each chunk for metric
            # parsing while passing it through unchanged. Non-SSE responses stay
            # buffered.
            if "text/event-stream" in h.get("content-type", ""):
                metrics.content_encoding = h.get("content-encoding", "")
                metrics.was_streamed = True
                metrics.stream_buf = bytearray()
                buf = metrics.stream_buf

                def stream_handler(chunk: bytes) -> bytes:
                    if chunk:
                        buf.extend(chunk)
                    return chunk

                flow.response.stream = stream_handler

        def response(self, flow: http.HTTPFlow):
            metrics = self.active_requests.pop(flow.id, None)
            if not metrics:
                return

            metrics.stream_end = time.perf_counter()
            # Streamed flows leave flow.response.content empty, so parse the bytes
            # the tap accumulated (decoded by the captured Content-Encoding).
            if metrics.was_streamed:
                content = _decode_sse_body(metrics.stream_buf or b"", metrics.content_encoding)
            else:
                content = flow.response.content
            if content:
                metrics.response_size_bytes = len(content)
                self._parse_sse(content, metrics)

            # A streamed flow that reached the response hook but never produced a
            # terminal stop_reason ended early (e.g. upstream closed mid-stream,
            # delivered here rather than to the error hook). Flag it aborted so it
            # is recorded for visibility but kept out of the averages.
            if metrics.was_streamed and (metrics.total_events > 0 or metrics.response_size_bytes > 0) and not metrics.stop_reason:
                metrics.aborted = True
                metrics.error_message = "stream ended before completion (no stop_reason)"

            if self.conversation_log and (
                metrics.total_events > 0 or metrics.response_size_bytes > 0 or metrics.output_tokens > 0
            ):
                saved, filename = self.conversation_log.add_turn(metrics)
                if saved:
                    ctx.log.info(f"[LOG] Checkpoint saved → {filename}")

        def error(self, flow: http.HTTPFlow):
            # A flow that errors mid-stream (client disconnect, upstream cut, etc.)
            # never reaches the response hook, so this hook records the partial turn
            # from whatever the tap salvaged, keeping the failure visible. pop()
            # keeps this safe against mitmproxy versions that fire both error and
            # response for one flow.
            metrics = self.active_requests.pop(flow.id, None)
            if not metrics:
                return

            metrics.stream_end = time.perf_counter()
            metrics.aborted = True
            metrics.error_message = str(flow.error) if flow.error else "stream aborted"
            if metrics.was_streamed and metrics.stream_buf:
                content = _decode_sse_body(metrics.stream_buf, metrics.content_encoding)
                if content:
                    metrics.response_size_bytes = len(content)
                    self._parse_sse(content, metrics)

            if self.conversation_log:
                saved, filename = self.conversation_log.add_turn(metrics)
                if saved:
                    ctx.log.info(f"[LOG] Aborted turn recorded → {filename}")

        def _parse_sse(self, content: bytes, m: TurnMetrics):
            try:
                text = content.decode("utf-8", errors="ignore")
            except Exception:
                return

            current_tool_use = None
            tool_input_parts = []
            event_idx = 0

            for data_str in _iter_sse_data(text):
                if not data_str or data_str == "[DONE]":
                    continue

                m.total_events += 1

                try:
                    data = json_loads(data_str)
                    etype = data.get("type", "")

                    if etype == "message_start":
                        msg = data.get("message", {})
                        m.message_id = msg.get("id", "")
                        usage = msg.get("usage", {})
                        m.input_tokens = usage.get("input_tokens", 0)
                        m.cache_creation_input_tokens = usage.get("cache_creation_input_tokens", 0)
                        m.cache_read_input_tokens = usage.get("cache_read_input_tokens", 0)
                        m.service_tier = usage.get("service_tier", "")
                        cc = usage.get("cache_creation", {})
                        if isinstance(cc, dict):
                            m.cache_creation_5m_tokens = cc.get("ephemeral_5m_input_tokens", 0)
                            m.cache_creation_1h_tokens = cc.get("ephemeral_1h_input_tokens", 0)

                    elif etype == "content_block_start":
                        cb = data.get("content_block", {})
                        cb_type = cb.get("type", "")
                        if cb_type == "thinking" and m.first_thinking_idx is None:
                            m.first_thinking_idx = event_idx
                        elif cb_type == "tool_use":
                            current_tool_use = {"name": cb.get("name", ""), "id": cb.get("id", ""), "input": ""}
                            tool_input_parts = []

                    elif etype == "content_block_delta":
                        delta = data.get("delta", {})
                        dtype = delta.get("type", "")
                        if dtype == "thinking_delta":
                            if m.first_thinking_idx is None:
                                m.first_thinking_idx = event_idx
                            m.thinking_parts.append(delta.get("thinking", ""))
                        elif dtype == "text_delta":
                            if m.first_text_idx is None:
                                m.first_text_idx = event_idx
                            m.text_parts.append(delta.get("text", ""))
                        elif dtype == "input_json_delta" and current_tool_use is not None:
                            tool_input_parts.append(delta.get("partial_json", ""))

                    elif etype == "content_block_stop":
                        if current_tool_use is not None:
                            input_str = "".join(tool_input_parts)
                            try:
                                current_tool_use["input"] = json_loads(input_str)
                            except Exception:
                                current_tool_use["input"] = input_str
                            m.tool_uses.append(current_tool_use)
                            current_tool_use = None
                            tool_input_parts = []

                    elif etype == "message_delta":
                        delta = data.get("delta", {})
                        if "stop_reason" in delta:
                            m.stop_reason = delta["stop_reason"]
                        # Final token counts (proxies may send real values here; overrides message_start if present)
                        usage = data.get("usage", {})
                        if "output_tokens" in usage:
                            m.output_tokens = usage["output_tokens"]
                        if "input_tokens" in usage:
                            m.input_tokens = usage["input_tokens"]
                        if "cache_creation_input_tokens" in usage:
                            m.cache_creation_input_tokens = usage["cache_creation_input_tokens"]
                        if "cache_read_input_tokens" in usage:
                            m.cache_read_input_tokens = usage["cache_read_input_tokens"]
                        ctx_mgmt = data.get("context_management", {})
                        if ctx_mgmt.get("applied_edits"):
                            m.context_mgmt_edits = ctx_mgmt["applied_edits"]

                except Exception:
                    pass

                event_idx += 1

    addons = [ClaudeLatencyAddon()]

except ImportError:
    addons = []


def main():
    import argparse
    import subprocess
    import shutil

    parser = argparse.ArgumentParser(description="Claude Trace Extractor")
    parser.add_argument("--port", "-p", type=int, default=8080, help="Proxy port (default: 8080)")
    if MODEL_REQUIRED:
        parser.add_argument("--model", "-m", required=True, help="Model name to use (e.g., claude-opus-4-7)")
    else:
        parser.add_argument("--model", "-m", default=CLAUDE_DEFAULT_MODEL, help=f"Model name to use (default: {CLAUDE_DEFAULT_MODEL})")
    permission_help = (
        "Permission mode "
        "(skip = --dangerously-skip-permissions, auto = --permission-mode auto)"
    )
    if CONFIG_REQUIRED:
        parser.add_argument("--effort-level", "-e", required=True, help="Thinking effort level (e.g., medium, high, xhigh)")
        parser.add_argument("--permission-mode", choices=CLAUDE_PERMISSION_MODES, required=True, help=permission_help)
    else:
        parser.add_argument("--effort-level", "-e", default=CLAUDE_DEFAULT_EFFORT_LEVEL, help=f"Thinking effort level (default: {CLAUDE_DEFAULT_EFFORT_LEVEL})")
        parser.add_argument("--permission-mode", choices=CLAUDE_PERMISSION_MODES, default=CLAUDE_DEFAULT_PERMISSION_MODE, help=f"{permission_help} (default: {CLAUDE_DEFAULT_PERMISSION_MODE})")
    parser.add_argument("--verbose", action="store_true", help="Pass --verbose to Claude (shows full tool calls, results, and thinking inline).")
    parser.add_argument("--disable-autoupdate", action="store_true", help="Set DISABLE_AUTOUPDATER=1 on the Claude launch command so Claude Code does not auto-update.")
    parser.add_argument("--show-thinking-summaries", action="store_true", help="Add showThinkingSummaries:true to the Claude --settings JSON so thinking content is returned in API responses (and captured in the JSON trace).")
    parser.add_argument("--disable-thinking", action="store_true", help="Disable extended thinking for the session: sets alwaysThinkingEnabled:false and env.MAX_THINKING_TOKENS:0 in the Claude --settings JSON and omits --thinking-display from the launch command. Default is thinking enabled.")
    parser.add_argument("--require-cli-version", metavar="X.Y.Z", default=None, help="Require an exact installed version of claude before running. Prints an install command and exits 1 if the installed version doesn't match or claude isn't on PATH. Detection runs `claude --version`.")
    parser.add_argument("--no-claude-config", action="store_true", help="Disable the CLAUDE_CONFIG_DIR redirect. By default the launch command sets CLAUDE_CONFIG_DIR to ./claude_config/active_<port>/ (a stable path keyed by proxy port so reusing a previously-printed launch command still works). Claude Code's session JSONL and debug log are written there during the run, then copied into ./logs/<run_id>/ at extractor shutdown; the runtime dir is renamed to ./claude_config/<run_id>/ at the same time so the next run starts with an empty active_<port>/. With this flag, no redirect happens and Claude Code uses the worker's regular ~/.claude/ instead.")
    args = parser.parse_args()

    if not is_port_free(args.port):
        print(f"ERROR: Port {args.port} is in use. Try --port {args.port + 1}")
        sys.exit(1)

    cert_path = get_cert_path()
    if not cert_path.exists():
        print("ERROR: mitmproxy certificate not found.")
        print("Run 'mitmproxy' once to generate certificates, then try again.")
        sys.exit(1)

    if args.require_cli_version is not None:
        err = enforce_cli_version("claude", args.require_cli_version)
        if err:
            print(err)
            sys.exit(1)

    installed_cli_version = get_cli_version("claude")
    installed_cli_str = f"claude {installed_cli_version}" if installed_cli_version else "claude (not detected)"

    script_dir = Path(__file__).parent.resolve()
    run_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{os.getpid()}"
    run_dir = script_dir / "logs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    # See main.py for the rationale on the two-path design. Briefly: the
    # runtime path is what goes in the launch command (stable per port so
    # stale launch commands still work); the final path is what the run's raw
    # state is renamed to at shutdown and what the JSON trace records.
    claude_config_runtime: Optional[Path] = None
    claude_config_final: Optional[Path] = None
    claude_config_row = ""
    if not args.no_claude_config:
        claude_config_runtime = script_dir / "claude_config" / f"active_{args.port}"
        claude_config_runtime.mkdir(parents=True, exist_ok=True)
        claude_config_final = script_dir / "claude_config" / run_id
        claude_config_row = f"  Claude config:  {claude_config_runtime}\n"

    system, is_wsl = get_platform_info()
    platform_str = f"{system}" + (" (WSL)" if is_wsl else "")

    launch_cmd = build_launch_command(
        cert_path, args.port, "claude", args.model,
        effort_level=args.effort_level,
        permission_mode=args.permission_mode,
        verbose=args.verbose,
        disable_autoupdate=args.disable_autoupdate,
        show_thinking_summaries=args.show_thinking_summaries,
        disable_thinking=args.disable_thinking,
        claude_config_dir=claude_config_runtime,
    )

    copied = copy_to_clipboard(launch_cmd)
    clipboard_msg = "(copied to clipboard)" if copied else "(copy the command below)"

    sep = "=" * 70
    print(f"""
{sep}
  CLAUDE CODE TRACE EXTRACTOR v{VERSION}
{sep}
  Platform:       {platform_str}
  Installed CLI:  {installed_cli_str}
  Proxy:          http://127.0.0.1:{args.port}
  Run dir:        {run_dir}
{claude_config_row}{sep}

  Run this in your project directory {clipboard_msg}:

  {launch_cmd}

{sep}
  Waiting for Claude Code to connect...
  When done: exit CLI first, then Ctrl+C here to save.
{sep}
""")

    mitmdump_cmd = shutil.which("mitmdump")
    if not mitmdump_cmd:
        print("ERROR: mitmdump not found. Install mitmproxy: pip install mitmproxy")
        sys.exit(1)

    mitmdump_args = [
        mitmdump_cmd, "-p", str(args.port),
        "-s", str(Path(__file__).resolve()),
        "--set", f"latency_log_dir={run_dir}",
        "--set", f"run_id={run_id}",
    ]
    if claude_config_final is not None:
        mitmdump_args += ["--set", f"claude_config_dir={claude_config_final}"]
    mitmdump_args += ["--set", f"thinking_disabled={'true' if args.disable_thinking else 'false'}"]
    mitmdump_args.append("--ssl-insecure")
    proc = subprocess.Popen(mitmdump_args)

    try:
        proc.wait()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user.")
        proc.terminate()
        proc.wait()

    print("\nProxy stopped.")

    preserved_dir: Optional[Path] = claude_config_final
    if claude_config_runtime is not None:
        def _copy_set(srcs, stem, ext):
            if len(srcs) == 1:
                shutil.copy2(srcs[0], run_dir / f"{stem}{ext}")
            elif len(srcs) > 1:
                for i, p in enumerate(srcs, 1):
                    shutil.copy2(p, run_dir / f"{stem}_{i}{ext}")
        _copy_set(sorted(claude_config_runtime.glob("projects/*/*.jsonl")), "session", ".jsonl")
        _copy_set(sorted(claude_config_runtime.glob("debug/*.txt")), "debug", ".txt")
        try:
            claude_config_runtime.rename(claude_config_final)
        except OSError as e:
            print(f"WARNING: could not rename {claude_config_runtime} -> {claude_config_final}: {e}")
            preserved_dir = claude_config_runtime

    def _order_key(p):
        name = p.name
        if name == "trace.json": return (0, name)
        if name == "transcript.txt": return (1, name)
        if name.startswith("session") and name.endswith(".jsonl"): return (2, name)
        if name.startswith("debug") and name.endswith(".txt"): return (3, name)
        return (4, name)
    files = sorted(
        (p for p in run_dir.iterdir() if p.is_file() and not p.name.startswith(".")),
        key=_order_key,
    )
    if files:
        print(f"\nFiles to share for this run ({run_dir}):")
        for p in files:
            print(f"  {p.name}")
        if preserved_dir is not None and preserved_dir.exists():
            print(f"\n(Originals and additional Claude Code state preserved at {preserved_dir})")


if __name__ == "__main__":
    main()
